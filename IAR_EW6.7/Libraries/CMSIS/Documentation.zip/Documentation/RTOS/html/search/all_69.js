var searchData=
[
  ['instances',['instances',['../structos_thread_def__t.html#aa4c4115851a098c0b87358ab6c025603',1,'osThreadDef_t']]],
  ['item_5fsz',['item_sz',['../structos_pool_def__t.html#a4c2a0c691de3365c00ecd22d8102811f',1,'osPoolDef_t::item_sz()'],['../structos_message_q_def__t.html#a4c2a0c691de3365c00ecd22d8102811f',1,'osMessageQDef_t::item_sz()'],['../structos_mail_q_def__t.html#a4c2a0c691de3365c00ecd22d8102811f',1,'osMailQDef_t::item_sz()']]]
];
